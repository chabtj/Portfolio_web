diamonds <- read.csv("diamonds.csv")
diamonds

summary(diamonds)

df <- data.frame(diamonds)

#Creating a new variable total_depth_percentage
diamonds <- transform(diamonds, totaldepth=2*diamonds$z/(diamonds$x+diamonds$y))


#Correlation Matrix
library(corrplot)
new1 = diamonds[c('carat', 'depth', 'table','price','x','y','z')]
# as colour
M = cor(new1)
corrplot(M, method="number")

#Graph Matrix
pairs(new1[,1:8])

##Model Building: Linear Regression
mod1= lm(log(price)~ log(carat) + cut+color+clarity+depth+x+y+z, data= diamonds)
summary(mod1)


#Correlation Matrix
library(corrplot)
new1 = diamonds[c('carat', 'cut','color', 'clarity','x','y','price')]
# as colour
M = cor(new1)
corrplot(M, method="number")



#We can also compare with a model before log transformation.
mod2= lm(price~carat+cut+color+clarity+depth+x+y+z, data= diamonds)
summary(mod2)




smod1 <- summary(mod1)
fval <- smod1$fstatistic 
library(broom)
kable(tidy(mod1), caption="'Tidy(mod1)' output")

glance(mod1)$statistic #Retrieves the F-statistic

# Summary statistics of the regression table
kable(glance(mod1),caption="Function 'glance(mod1)' output", digits=2,col.names=(c("Rsq","AdjRsq","sig","F","pF","K","logL","AIC","BIC","dev","df.res", "Obs")))


#test for hetroscedasticity(Breusch-Pagan Test and Graphical approach)
plot(mod1)
plot(mod3)
install.packages("lmtest")
library(lmtest)
bptest(mod1)
bptest(mod2)
bptest(mod3)

#vif test and rectification for multicolinearlity
vif(mod1)
diamonds <- transform(diamonds, totaldepth=2*diamonds$z/(diamonds$x+diamonds$y))
mod3= lm(log(price)~ log(carat) + cut+color+clarity+totaldepth+table, data= diamonds)
summary(mod3)
vif(mod3)
# graphical approach for multicollinearity
plot(mod1)

#robust heteroskedasticity
library(car)
mod3_robust = hccm(mod3, type = "hc1")
(data.HC1 = coeftest(mod3, vcov=mod3_robust))


#shapiro test for normality of residuals
shapiro.test(mod1$residuals[0:5000])
shapiro.test(mod3$residuals[0:5000])
#Rest test for OVB
resettest(mod1, power=2, type='fitted')
resettest(mod3, power=2, type='fitted')


