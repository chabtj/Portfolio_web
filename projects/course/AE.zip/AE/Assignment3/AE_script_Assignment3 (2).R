#### 6.5 hours/day daily seasonality #######
Netflix_ts<- ts(AE3_data$Close,frequency =(6.5*60), start=c(1,1),end=c(5,391)) 
plot.ts(Netflix_ts)
Netflix_decomposed <-decompose(diff(Netflix_ts))
plot(Netflix_decomposed)
adjusted_netflix <- Netflix_ts - Netflix_decomposed$seasonal
plot.ts(adjusted_netflix)
adf.test(adjusted_netflix)
adf.test(diff((adjusted_netflix)))
plot.ts(diff(adjusted_netflix))
finalmodel = diff(adjusted_netflix)
acf(finalmodel)
pacf(finalmodel)

auto.arima(adjusted_netflix, ic="aic")
auto.arima(adjusted_netflix,ic="bic")

arima_Netflix<- Arima(adjusted_netflix, order=c(2,1,2))
forecast(arima_Netflix, h=5 , level=c(99.5))
Netflix_forecasts<- forecast(arima_Netflix, h=5 , level=c(99.5))
Box.test(Netflix_forecasts$residuals, lag=20, type="Ljung-Box")
acf(Netflix_forecasts$residuals)
hist(Netflix_forecasts$residuals)
plot.ts(Netflix_forecasts$residuals)
