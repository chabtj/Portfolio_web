install.packages("rugarch")
install.packages("readxl")
install.packages("forecast")
library(readxl)
library(rugarch)
library(forecast)
Daily <- read_excel("C:/Users/Vishnu/Downloads/DATA_FRAM.xlsx", sheet = "Daily")
Daily_data <- ts((tail(Daily$TCS, -1)/head(Daily$TCS, -1))-1)
d_ugspec = ugarchspec()
d_ugspec
d_egspec = ugarchspec(variance.model=list(model="eGARCH"))
d_egspec
d_ugfit = ugarchfit(spec=d_ugspec,data=Daily_data)
d_ugfit
d_egfit = ugarchfit(spec=d_egspec,data=Daily_data)
d_egfit
d_ugforecast = ugarchforecast(d_ugfit,n.ahead=10)
d_ugforecast
d_egforecast= ugarchforecast(d_egfit,n.ahead=10)
d_egforecast
d_ugspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="sGARCH",garchOrder=c(1,1)))
d_ugspec2
d_egspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="eGARCH")) #model shows lower AIC values when mean model is set to ARMA(0,0)
d_egspec2
d_ugfit2 = ugarchfit(spec=d_ugspec,data=Daily_data)
d_ugfit2
d_egfit2 = ugarchfit(spec=d_egspec,data=Daily_data)
d_egfit2
d_ugforecast2 = ugarchforecast(d_ugfit,n.ahead=10)
d_ugforecast2
d_egforecast2 = ugarchforecast(d_egfit2,n.ahead=10)
d_egforecast2


Weekly <- read_excel("C:/Users/Vishnu/Downloads/DATA_FRAM.xlsx",sheet = "Weekly")
Weekly_data <- ts((tail(Weekly$TCS, -1)/head(Weekly$TCS, -1))-1)
w_ugspec = ugarchspec()
w_ugspec
w_egspec = ugarchspec(variance.model=list(model="eGARCH"))
w_egspec
w_ugfit = ugarchfit(spec=w_ugspec,data=Weekly_data)
w_ugfit
w_egfit = ugarchfit(spec=w_egspec,data=Weekly_data)
w_egfit
w_ugforecast = ugarchforecast(w_ugfit,n.ahead=10)
w_ugforecast
w_egforecast = ugarchforecast(w_egfit,n.ahead=10)
w_egforecast
w_ugspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="sGARCH",garchOrder=c(1,1)))
w_ugspec2
w_egspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="eGARCH")) #model shows lower AIC values when mean model is set to ARMA(0,0
w_egspec2
w_ugfit2 = ugarchfit(spec=w_ugspec2,data=Weekly_data)
w_ugfit2
w_egfit2 = ugarchfit(spec=w_egspec2,data=Weekly_data)
w_egfit2
w_ugforecast2 = ugarchforecast(w_ugfit,n.ahead=10)
w_ugforecast2
w_egforecast2 = ugarchforecast(w_egfit2,n.ahead=10)
w_egforecast2


Monthly <- read_excel("C:/Users/Vishnu/Downloads/DATA_FRAM.xlsx",sheet = "Monthly")
Monthly_data <- ts((tail(Monthly$TCS, -1)/head(Monthly$TCS, -1))-1)
m_ugspec = ugarchspec()
m_ugspec
m_egspec = ugarchspec(variance.model=list(model="eGARCH"))
m_egspec      #Less than 100 data points, model cannot be fit to EGARCH
m_ugfit = ugarchfit(spec=m_ugspec,data=Monthly_data)
m_ugfit
m_egfit = ugarchspec(spec=m_egspec,data=Monthly_data)
m_egfit
m_ugforecast = ugarchforecast(m_ugfit,n.ahead=10)
m_ugforecast
m_egforecast = ugarchforecast(m_egfit,n.ahead=10)
m_ugspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="sGARCH",garchOrder=c(1,1)))
m_ugspec2
m_egspec2 = ugarchspec(mean.model=list(armaOrder=c(0,0)),variance.model=list(model="eGARCH")) #Throws an error as there as less than a hundred data points
m_egspec2
m_ugfit2 = ugarchfit(spec=m_ugspec2,data=Monthly_data)
m_ugfit2
m_egfit2 = ugarchfit(spec=m_egspec2,data=Monthly_data)
m_egfit2
m_ugforecast2 = ugarchforecast(ugfit,n.ahead=10)
m_ugforecast2
m_egforecast2 = ugarchforecast(egfit2,n.ahead=10)
m_egforecast2

