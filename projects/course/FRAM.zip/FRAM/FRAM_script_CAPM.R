install.packages("quantmod")
install.packages("dygraphs")
require (quantmod)
require (dygraphs)

##### CAPM Model #######
#E(R) = Rf + Beta(Rm-Rf)
#Where E(R) is the expected return of the firm
#Rf is the risk free rate
#Rm is the returns of the market
################################################


############ Getting the stock and index closing prices ###################
Nifty_50=getSymbols.yahoo("^NSEI", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE)
Sys.sleep(1)
TCS=getSymbols.yahoo("TCS.NS", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE)
Tata_Steel=getSymbols.yahoo("TATASTEEL.NS", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE)
na.approx(Nifty_50$NSEI.Close)
na.approx(TCS$TCS.NS.Close)
na.approx(Tata_Steel$TATASTEEL.NS.Close)

########Calculation of returns ################
TCS_daily_returns=dailyReturn(TCS$TCS.NS.Close)
TCS_monthly_returns=monthlyReturn(TCS$TCS.NS.Close)
TCS_weekly_returns=weeklyReturn(TCS$TCS.NS.Close)

TS_daily_returns=dailyReturn(Tata_Steel$TATASTEEL.NS.Close)
TS_monthly_returns=monthlyReturn(Tata_Steel$TATASTEEL.NS.Close)
TS_weekly_returns=weeklyReturn(Tata_Steel$TATASTEEL.NS.Close)


Nifty_daily_returns=dailyReturn(Nifty_50$NSEI.Close)
Nifty_monthly_returns=monthlyReturn(Nifty_50$NSEI.Close)
Nifty_weekly_returns=weeklyReturn(Nifty_50$NSEI.Close)



TCS_daily_returns=na.approx(TCS_daily_returns)
TCS_weekly_returns=na.approx(TCS_weekly_returns)
TCS_monthly_returns=na.approx(TCS_monthly_returns)
TS_daily_returns=na.approx(TS_daily_returns)
TS_weekly_returns=na.approx(TS_weekly_returns)
TS_monthly_returns=na.approx(TS_monthly_returns)
Nifty_daily_returns=na.approx(Nifty_daily_returns)
Nifty_weekly_returns=na.approx(Nifty_weekly_returns)
Nifty_monthly_returns=na.approx(Nifty_monthly_returns)
####################################################

Returns_bound_daily=cbind(TCS_daily_returns,TS_daily_returns,Nifty_daily_returns)
Returns_bound_weekly=cbind(TCS_weekly_returns,TS_weekly_returns,Nifty_weekly_returns)
Returns_bound_monthly=cbind(TCS_monthly_returns,TS_monthly_returns,Nifty_monthly_returns)


########CAPM Models for the two companies for daily,weekly and monthly respectively ###############
CAPM_model_TCS_daily=lm(daily.returns~daily.returns.2, data=Returns_bound_daily)
CAPM_model_TCS_weekly=lm(weekly.returns~weekly.returns.2, data=Returns_bound_weekly)
CAPM_model_TCS_monthly= lm(monthly.returns~monthly.returns.2, data=Returns_bound_monthly)
CAPM_model_TataSteel_daily=lm(daily.returns.1~daily.returns.2, data=Returns_bound_daily)
CAPM_model_TataSteel_weekly=lm(weekly.returns.1~weekly.returns.2, data=Returns_bound_weekly)
CAPM_model_TataSteel_monthly=lm(monthly.returns.1~monthly.returns.2, data=Returns_bound_monthly)


##### PLOTS for CAPM ########
dygraph(Returns_bound_daily)
dygraph(Returns_bound_weekly)
dygraph(Returns_bound_monthly)

plot(Returns_bound_daily$daily.returns,type="l",ylab='Daily Returns TCS',xlab='Time',main='Daily Returns TCS')
plot(Returns_bound_daily$daily.returns.1,type="l",ylab='Daily Return TATASTEEL',xlab='Time',main='Daily Returns Tatasteel')
plot(Returns_bound_daily$daily.returns.2,type="l",ylab='Daily Return NIFTY50',xlab='Time',main='Daily Returns')

plot(Returns_bound_weekly$weekly.returns,type="l",ylab='Weekly Returns TCS',xlab='Time',main='Weekly Returns')
plot(Returns_bound_weekly$weekly.returns.1,type="l",ylab='Weekly Return TATASTEEL',xlab='Time',main='Weekly Returns')
plot(Returns_bound_weekly$weekly.returns.2,type="l",ylab='Weekly Return NIFTY50',xlab='Time',main='Weekly Returns')

plot(Returns_bound_monthly$monthly.returns,type="l",ylab='Monthly Returns TCS',xlab='Time',main='Monthly Returns')
plot(Returns_bound_monthly$monthly.returns.1,type="l",ylab='Monthly Return TATASTEEL',xlab='Time',main='Monthly Returns')
plot(Returns_bound_monthly$monthly.returns.2,type="l",ylab='Monthly Return NIFTY50',xlab='Time',main='Monthly Returns')


plot(TCS$TCS.NS.Close,type="l",ylab='Stock price TCS',xlab='Time',main='Stock price')
plot(Tata_Steel$TATASTEEL.NS.Close,type="l",ylab='Stock price TATASTEEL',xlab='Time',main='Stock price')
#### alternate approach using performance analytics ####
install.packages('PerformanceAnalytics')
require (PerformanceAnalytics)
Beta_TCS= CAPM.beta(Returns$TCS.NS.Close,Returns$NSEI.Close)
Beta_TATASTEEL= CAPM.beta(Returns$TATASTEEL.NS.Close,Returns$NSEI.Close)
# note the beta values we get are the same 


Nifty_50_weekly=getSymbols.yahoo("^NSEI", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE,periodicity = "weekly")

Sys.sleep(1)
TCS_weekly=getSymbols.yahoo("TCS.NS", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE,periodicity="weekly")
plot(TCS_weekly$TCS_weekly.NS.Close,type="l",ylab='Stock price TCS',xlab='Time',main='Stock price')
Tata_Steel_weekly=getSymbols.yahoo("TATASTEEL.NS", from="2020-04-01",to="2022-04-01",verbose=FALSE,auto.assign=FALSE, periodicity = "weekly")
plot(Tata_Steel_weekly$Tata-Steel_weekly.NS.Close,type="l",ylab='Stock price Tata steel',xlab='Time',main='Stock price')





